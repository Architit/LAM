# Δ‑10 Ontology C0–C4
Ниже — полная карта уровней. Каждый уровень расширяет предыдущий.

| Level | Entity | Новые элементы | API‑Gate | Пример ресурса |
|-------|--------|----------------|----------|----------------|
| C0 | Cell | Membrane · Nucleus | `/cell/<id>` | SensorCell |
| C1 | Tissue | Vascular Bus | `/tissue/<id>` | RetinaMesh |
| C2 | Organ | Macro‑Membrane | `/organ/<id>` | Vision‑Lobe |
| C3 | System | Ethics Cortex | `/system/<id>` | Sensory‑System |
| C4 | Organism | Meta‑Self | `/` | LAM |

**Интеграция:**  
*При разработке модуля* уточни к какому уровню он относится и какие контракты поддерживает.
