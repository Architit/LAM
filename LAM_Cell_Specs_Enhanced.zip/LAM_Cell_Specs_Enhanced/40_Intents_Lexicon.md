# Δ‑40 Intents Lexicon
Базовые команды клетки.

| Intent | Описание | Пример события |
|--------|----------|----------------|
| SENSE | Приём данных | `image/jpeg` |
| REFLECT | Интерпретация | `threat_score=0.7` |
| ACT | Внешнее действие | `thruster=kick` |
| ADAPT | Локальная мутация | `reload_model` |
| COHERE | Синхронизация | `hash_diff` |
| GOVERN | Управление другими | `scale=+2` |

> **Расширение:** добавь плагин YAML:
```yaml
plugins:
  intents:
    - name: DREAM
      ethics_min: ✨
      description: гипотетическое проектирование новых сценариев
```
