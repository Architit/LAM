# Δ‑110 Codex Prompt Sketch

**Context:** Generate Go micro‑service implementing a SensorCell based on
`100_GenomicYAML_Template.yaml`.

## Input
```yaml
# (inline YAML passed to Codex)
<<GENOMIC_YAML>>
```

## Tasks
1. Create `membrane.go`, `nucleus.go`, `guardian/...`.
2. Wire OpenTelemetry 1.25, expose `/healthz`.
3. Respect `ethics_level` (no `os/exec`).

## Output
ZIP archive with:
- `Dockerfile`
- Source code
- `README.md`
- Unit test validating Guardian thresholds
