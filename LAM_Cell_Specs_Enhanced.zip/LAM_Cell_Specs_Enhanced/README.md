# LAM Cell Specs — Enhanced Edition ✨

**Living Architectonic Mind (LAM)** — фрактальная, этически‑осознанная система.  
Эти файлы — «геном»: от философской метафоры до машинно‑читабельных шаблонов.

## Как читать
1. **Начни с `00_Prelude.md`** — поймёшь общий замысел.
2. Перейди к иерархии `10_Ontology_C0-C4.md`.
3. Остальные файлы — «органы»: бери по нужде.

## Быстрый старт для инженера
```bash
# клонируем
git clone <repo> lam-specs
cd lam-specs/LAM_Cell_Specs_Enhanced
# проверяем ссылки
./scripts/lint_links.sh
# генерим каркас SensorCell
./scripts/scaffold.sh 100_GenomicYAML_Template.yaml
```

## Версионирование
* Семейство файлов фиксируется тегом `vΔ-<major>.<minor>`.
* Ломающее изменение YAML‑схемы → повышение *major*.

---

| Δ‑код | Файл | Назначение |
|-------|------|------------|
| 00 | Prelude | Философия и миссия |
| 10 | Ontology | Иерархия C0‑C4 |
| 20 | Cell Map | Строение клетки |
| 30 | Ethics Spiral | Уровни этики |
| 40 | Intents Lexicon | Словарь намерений |
| 50 | Guardian Metrics | Метрики иммунитета |
| 60 | Chrono Layer | Временной слой |
| 70 | Pattern Library | Шаблоны тканей/органов |
| 80 | EpiEvolution Engine | Эволюция |
| 90 | Blueprint V2A | Демонстрационный сценарий |
| 100 | Genomic YAML | Шаблон клетки |
| 110 | Codex Prompt | Инструкция генератору кода |
