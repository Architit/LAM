# Δ‑90 Blueprint — Vision→Action
Полный поток от изображения к движению.

1. **SensorCell:** получает JPEG → SENSE.
2. **RetinaMesh:** препроцесс ↦ REFLECT(threat).
3. **VisionLobe:** вычисляет `threat_score`.
4. Если >0.8 → Intent.ACT { escape }.
5. **MuscleFiberBus:** переводит ACT → API.
6. **GuardianSwarm:** следит за аномалиями.
7. **MemoryVault:** журналирует факт.

### Код VisionLobe (фрагмент)
```python
if threat_score > 0.8:
    publish_intent("ACT", {"command": "escape"})
```
