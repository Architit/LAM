# Δ‑20 Cell Map
Подробная анатомия базовой клетки.

| Метафора | Примитив | Пример кода | Назначение |
|----------|----------|-------------|------------|
| Мембрана | `EdgeInterface` | `membrane.go` | Приём и публикация событий |
| Ядро | `IntentDNA` | `nucleus.go` | Инварианты, этика |
| Иммунитет | `GuardianMesh` | `guardian/…` | Слежение, апоптоз |

### Пример фрагмента кода (Go)
```go
// membrane.go
http.HandleFunc("/ingress", guardian.Wrap(validate(IngressHandler)))
```

**Совет:** держи Membrane «тонким»; логику помещай в ядро.
