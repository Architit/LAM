# Δ‑50 Guardian Metrics
Чёткий набор сигналов здоровья.

| Metric | Warn ≥ | Crit ≥ | Где хранится? |
|--------|--------|--------|---------------|
| Δt_heartbeat | 3 s | 10 s | Prometheus |
| ATP_left | 25 % | 10 % | /proc/lam/atp |
| anomaly_rate | 0.02 | 0.05 | Guardian cache |

**Конфигурация Guardian example:**
```yaml
guardian:
  thresholds:
    heartbeat: { warn: 3s, crit: 10s }
    anomalyRate: { warn: 0.02, crit: 0.05 }
```
