# Δ‑70 Pattern Library
Шаблоны для быстрого старта.

## RetinaMesh
```yaml
cell:
  kind: SensorCell
  intents: [SENSE, COHERE]
  plugins: { vision: true }
```

## MuscleFiberBus
```yaml
cell:
  kind: Actuator
  intents: [ACT]
  resources: { energy: 500mCPU }
```
