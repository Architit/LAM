# Δ‑80 EpiEvolution Engine
Механизмы обновления и роста.

| Фаза | Триггер | Действие |
|------|---------|----------|
| Mitosis | Merge PR | Клон без мутаций |
| Meiosis | R&D‑флаг | Клон + мутация Intents |
| Symbiogenesis | 2 Organs Ready | Слияние |
| Autophagy | Deprecated Tag | Утилизация |

**API вызов Meiosis:**
```bash
curl -XPOST /organ/vision-lobe/meiosis -d '{ "mutate": ["INTENT=DREAM"] }'
```
