# Δ‑30 Ethics Spiral
Уровни этического контроля — от лабораторных тестов до полного иммунитета.

| Level | Badge | Запреты | Разрешённые Intents |
|-------|-------|---------|---------------------|
| 0 | 📃 | — | SENSE, REFLECT |
| 1 | 🌱 | Личные данные | + ACT |
| 2 | 🫀 | Mass Restart | + ADAPT |
| 3 | 🛡 | Self‑mutation без ревью | + COHERE |
| 4 | ✨ | Harm ↦ self‑sacrifice | + GOVERN |
| 5 | ∞ | Внешний override | All |

**Как применить:**  
В YAML клетки добавь `ethics_level: "🫀"` и убедись, что Guardian тестирует запреты.
